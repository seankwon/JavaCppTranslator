// java_ast.h            see license.txt for copyright and terms of use
// a level of indirection for including the generated AST header file

#ifndef JAVA_AST_H
#define JAVA_AST_H

#include "java.ast.gen.h"     // Ella's name for the JAVA AST declarations file

#endif // JAVA_AST_H
