class Foo {
  Foo foo = new Foo();
}
